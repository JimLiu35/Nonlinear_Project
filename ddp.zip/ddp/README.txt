run the following scripts to see the examples:

ddp_pnt : double integrator 
ddp_pnt_obst : double integrator with simple disk obstacles
ddp_car : second-order car-like model
ddp_arm : 2-dof robotic arm 
